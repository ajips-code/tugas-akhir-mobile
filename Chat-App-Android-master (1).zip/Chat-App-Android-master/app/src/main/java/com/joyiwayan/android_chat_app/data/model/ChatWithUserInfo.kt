package com.joyiwayan.android_chat_app.data.model

import com.joyiwayan.android_chat_app.data.db.entity.Chat
import com.joyiwayan.android_chat_app.data.db.entity.UserInfo

data class ChatWithUserInfo(
    var mChat: Chat,
    var mUserInfo: UserInfo
)
