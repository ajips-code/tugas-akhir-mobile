package com.joyiwayan.android_chat_app.data.model

data class Login(
    var email: String = "",
    var password: String = ""
)